from django.shortcuts import render, HttpResponse
def index(request):
    return render(request, 'index.html')

# Create your views here.
# edited for dojo survey revisited
from django.shortcuts import render, redirect 
def create_user(request):
    print("Got POST data!")
    request.session['name'] = request.POST['name']
    request.session['email'] = request.POST['email']
    return redirect('/result')	

def result(request):
    context = {
    'name': request.session['name'],
    'email': request.session['email'],
}
    return render(request, 'result.html', context)



#         context = { 
#     'name': request.POST['name'],
#     'location': request.POST['location'],
#     'language': request.POST['language'],
#     'comment': request.POST['comment']
# }
#     return render(request, 'index.html', context)

    
    
    
    
    # return render(request, 'result.html', context)
# def index(request):
#     context = {
#     	"name": "Noelle",
#     	"favorite_color": "turquoise",
#     	"pets": ["Bruce", "Fitz", "Georgie"]
#     }
#     return render(request, "index.html", context)

# forms always use post requests, all others use git requests